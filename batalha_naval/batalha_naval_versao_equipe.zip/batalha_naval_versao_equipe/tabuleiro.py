
nome_da_equipe = "Equipe X"
tabuleiro = [(1, 1),(2, 1),(3, 1),(4, 1),
             (6, 6),
             (2, 6), (3, 7), (4, 6)
              ]
